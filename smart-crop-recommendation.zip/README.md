# 🌱 Smart Crop Recommendation System

A beginner-friendly web prototype that recommends a suitable crop using basic soil and weather parameters.

## Features
- Temperature input
- Rainfall input
- Soil pH input
- Crop recommendation
- Simple responsive web interface

## Technologies
- Python
- Flask
- HTML
- CSS

## Project Structure

```text
smart-crop-recommendation/
├── app.py
├── requirements.txt
├── README.md
├── templates/
│   └── index.html
└── static/
    └── style.css
```

## Run Locally

```bash
pip install -r requirements.txt
python app.py
```

Open `http://127.0.0.1:5000` in your browser.

## Future Scope
- Train an ML model using N, P, K, temperature, humidity, pH and rainfall.
- Add more crops and regional datasets.
- Add weather API integration.
- Add farmer-friendly Hindi/English support.

> This repository is an educational prototype, not agricultural advice.
