from flask import Flask, render_template, request

app = Flask(__name__)

# Demo recommendation rules. Replace with an ML model for production use.
CROPS = {
    "rice": {"min_temp": 20, "max_temp": 35, "min_rain": 150, "max_ph": 7.5},
    "wheat": {"min_temp": 10, "max_temp": 25, "min_rain": 30, "max_ph": 7.5},
    "maize": {"min_temp": 18, "max_temp": 32, "min_rain": 50, "max_ph": 7.5},
    "cotton": {"min_temp": 21, "max_temp": 35, "min_rain": 50, "max_ph": 8.0},
    "sugarcane": {"min_temp": 20, "max_temp": 35, "min_rain": 100, "max_ph": 8.0},
    "potato": {"min_temp": 10, "max_temp": 25, "min_rain": 30, "max_ph": 7.5},
    "tomato": {"min_temp": 18, "max_temp": 30, "min_rain": 40, "max_ph": 7.5},
    "soybean": {"min_temp": 20, "max_temp": 32, "min_rain": 60, "max_ph": 7.5},
}

def recommend(temp, rainfall, ph):
    scores = {}
    for crop, rule in CROPS.items():
        score = 0
        if rule["min_temp"] <= temp <= rule["max_temp"]:
            score += 2
        else:
            score += max(0, 1 - abs(temp - max(min(temp, rule["max_temp"]), rule["min_temp"])) / 15)

        if rainfall >= rule["min_rain"]:
            score += 1
        if ph <= rule["max_ph"]:
            score += 1

        scores[crop] = score

    return max(scores, key=scores.get)

@app.route("/", methods=["GET", "POST"])
def home():
    recommendation = None
    error = None

    if request.method == "POST":
        try:
            temp = float(request.form["temperature"])
            rainfall = float(request.form["rainfall"])
            ph = float(request.form["ph"])
            recommendation = recommend(temp, rainfall, ph).title()
        except (ValueError, KeyError):
            error = "Please enter valid numeric values."

    return render_template("index.html", recommendation=recommendation, error=error)

if __name__ == "__main__":
    app.run(debug=True)
